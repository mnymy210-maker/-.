# Fanus Bot

## Railway settings

- Start command: `python bot.py`
- Environment variable:
  - Name: `BOT_TOKEN`
  - Value: توکن جدید ربات از BotFather

Never put the bot token inside GitHub.
