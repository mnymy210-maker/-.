import os
import asyncio
import sqlite3
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
    PollAnswerHandler,
)

TOKEN = os.environ["BOT_TOKEN"]
DB_FILE = "scores.db"
POINTS = [10, 7, 5]

polls = {}


def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS scores (
                user_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                score INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.commit()


def add_score(user_id, name, points):
    with sqlite3.connect(DB_FILE) as conn:
        conn.execute("""
            INSERT INTO scores(user_id, name, score)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                name=excluded.name,
                score=score + excluded.score
        """, (user_id, name, points))
        conn.commit()


def get_score(user_id):
    with sqlite3.connect(DB_FILE) as conn:
        row = conn.execute(
            "SELECT score FROM scores WHERE user_id = ?", (user_id,)
        ).fetchone()
        return row[0] if row else 0


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🌙🏮 به ربات فانوس توحید خوش آمدی!\n\n"
        "برای ارسال سؤال در گروه، دستور /question را بفرست.\n"
        "برای شروع شمارش معکوس و سؤال، /startgame را بفرست.\n"
        "برای دیدن امتیاز خودت، /score را بفرست.\n"
        "برای دیدن جدول، /ranking را بفرست."
    )


async def get_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        f"شناسه این چت: {update.effective_chat.id}"
    )


async def send_question(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = await update.effective_chat.send_poll(
        question="کدام سورهٔ قرآن به نام یک حشره نام‌گذاری شده است؟",
        options=[
            "سوره نحل",
            "سوره فیل",
            "سوره عنکبوت",
            "سوره نمل",
        ],
        type="quiz",
        correct_option_id=3,
        is_anonymous=False,
    )

    polls[message.poll.id] = {
        "chat_id": update.effective_chat.id,
        "winners": [],
        "answered_users": set(),
    }


async def startgame(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🌙🔥 شب مسابقهٔ فانوس توحید شروع شد! 🔥🌙\n\n🎯 آماده‌اید؟"
    )
    for number in (3, 2, 1):
        await asyncio.sleep(1)
        await update.message.reply_text(f"⏳ {number}...")
    await asyncio.sleep(1)
    await update.message.reply_text("💥🚨 شلیک سؤال! 🚨💥")
    await send_question(update, context)


async def handle_poll_answer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    answer = update.poll_answer
    poll_id = answer.poll_id

    if poll_id not in polls:
        return

    poll_data = polls[poll_id]
    user = answer.user

    if user.id in poll_data["answered_users"]:
        return

    poll_data["answered_users"].add(user.id)

    if not answer.option_ids or answer.option_ids[0] != 3:
        return

    if len(poll_data["winners"]) >= 3:
        return

    place = len(poll_data["winners"])
    points = POINTS[place]
    poll_data["winners"].append(user.id)

    add_score(user.id, user.full_name, points)
    total = get_score(user.id)
    medals = ["🥇", "🥈", "🥉"]

    await context.bot.send_message(
        chat_id=poll_data["chat_id"],
        text=(
            f"{medals[place]} آفرین {user.full_name}!\n\n"
            f"🎯 شما نفر {place + 1} پاسخ درست بودید.\n"
            f"🏆 امتیاز این سؤال: {points}\n"
            f"📊 مجموع امتیاز شما: {total}"
        ),
    )


async def ranking(update: Update, context: ContextTypes.DEFAULT_TYPE):
    with sqlite3.connect(DB_FILE) as conn:
        rows = conn.execute(
            "SELECT name, score FROM scores ORDER BY score DESC LIMIT 10"
        ).fetchall()

    if not rows:
        await update.message.reply_text("📊 هنوز امتیازی ثبت نشده است.")
        return

    text = "🏆 جدول رتبه‌بندی فانوس توحید 🏆\n\n"
    for rank, (name, score) in enumerate(rows, 1):
        text += f"{rank}. {name} — {score} امتیاز\n"

    await update.message.reply_text(text)


async def score(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_score = get_score(update.effective_user.id)
    await update.message.reply_text(f"🏆 امتیاز شما: {user_score}")


def main():
    init_db()

    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("id", get_id))
    app.add_handler(CommandHandler("quiz", send_question))
    app.add_handler(CommandHandler("question", send_question))
    app.add_handler(CommandHandler("startgame", startgame))
    app.add_handler(CommandHandler("ranking", ranking))
    app.add_handler(CommandHandler("score", score))
    app.add_handler(PollAnswerHandler(handle_poll_answer))

    print("Fanus bot is running...")
    app.run_polling()


if __name__ == "__main__":
    main()
